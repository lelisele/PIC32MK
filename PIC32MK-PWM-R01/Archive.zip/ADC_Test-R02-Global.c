//!----------------------------------------------------------------------------
//! electronics-lis
//! CH-2000 Neuchatel
//! info@electronics-lis.com
//! https://electronics-lis.com
//! L. Lisowski 20 January 2018
//!----------------------------------------------------------------------------
//!----------------------------------------------------------------------------
// PIC32MK ADC tests
//!----------------------------------------------------------------------------
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <C:\Program Files (x86)\Microchip\xc32\v1.44\pic32mx\include\proc\p32mk1024mcf064.h>
#include <xc.h>            
#include <sys/attribs.h> 
//!----------------------------------------------------------------------------
//!----------------------------------------------------------------------------
//! This part need to be adapted for your application. 
#pragma config PWMLOCK = OFF, FUSBIDIO2 = OFF, FVBUSIO2 = OFF, PGL1WAY = OFF    
#pragma config PMDL1WAY = OFF, IOL1WAY = OFF, FUSBIDIO1 = OFF, FVBUSIO1 = OFF                    
// DEVCFG2
#pragma config FPLLIDIV = DIV_1, FPLLRNG = RANGE_5_10_MHZ, FPLLICLK = PLL_POSC         
#pragma config FPLLMULT = MUL_48, FPLLODIV = DIV_4, VBATBOREN = ON, DSBOREN = ON      
#pragma config DSWDTPS = DSPS32, DSWDTOSC = LPRC, DSWDTEN = OFF, FDSEN = OFF          
#pragma config BORSEL = HIGH, UPLLEN = OFF               
// DEVCFG1
#pragma config FNOSC = SPLL, DMTINTV = WIN_127_128, FSOSCEN = OFF, IESO = ON
#pragma config POSCMOD = HS, OSCIOFNC = ON, FCKSM = CSECME, WDTPS = PS1048576   
#pragma config WDTSPGM =STOP,WINDIS = NORMAL, FWDTEN = OFF, FWDTWINSZ = WINSZ_25
#pragma config DMTCNT = DMT31, FDMTEN = ON
// DEVCFG0
#pragma config DEBUG = OFF, JTAGEN = OFF, ICESEL = ICS_PGx1, TRCEN = ON
#pragma config BOOTISA = MIPS32,FSLEEP = OFF, DBGPER = PG_ALL, SMCLR = MCLR_NORM     
#pragma config SOSCGAIN = GAIN_2X, SOSCBOOST = ON, POSCGAIN = GAIN_LEVEL_3
#pragma config POSCBOOST = ON, EJTAGBEN = NORMAL 
// DEVCP
#pragma config CP = OFF                 // Code Protect (Protection Disabled)
//! That are my Configuration Bits version, you need adapt them for your application 
//!----------------------------------------------------------------------------
//!----------------------------------------------------------------------------
#define _SYSCLK 120000000L
#define _PBCLK (_SYSCLK/2)
#define _UARTspeed   115200
/*********************************/
//! Type declarations
/*********************************/
typedef signed char  int8;
typedef unsigned char uint8;
typedef short int16;
typedef unsigned short uint16;
typedef long int32;
typedef unsigned long uint32;
/*********************************/
//! Local Variables
/*********************************/
char i;
/*********************************/
//! Function prototype
/*********************************/
void initU1ART(void);
void initADC(void);
/*********************************/
//! main 
void main()
{ 
  
    __builtin_enable_interrupts();  // global interrupt enable
    __XC_UART = 1;                  // printf on the U1ART    
    INTCONbits.MVEC = 1; // Set the interrupt controller for multi-vector mode  
    PMCONbits.ON = 0;               //! no PMP
    // Function initialization
    initU1ART();
    printf ("\n\r This is my first ADC test \n\r"); 
    initADC();
    //! PBCLK2 clock initialization
    PB2DIVbits.ON = 1;              //! PBCLK2 clock  => ON 
    uint16 result[3];
    

    while (1) // U1ART test
	{
        char i;
        while( !U1STAbits.URXDA);   //! wait until data available in RX buffer
        i = U1RXREG;                //1 Hit any key
        while( U1STAbits.UTXBF);    //! wait while TX buffer full
        U1TXREG = i;                //! Echo
        while( !U1STAbits.TRMT);    //! wait for last transmission to finish
        if (i == 'c')
        {
              /* Trigger a conversion */
            ADCCON3bits.GSWTRG = 1;
            /* Wait the conversions to complete */
            while (ADCDSTAT1bits.ARDY0 == 0);
            /* fetch the result */
            result[0] = ADCDATA0;
            while (ADCDSTAT1bits.ARDY3 == 0);
            /* fetch the result */
            result[1] = ADCDATA3;
            while (ADCDSTAT1bits.ARDY4 == 0);
            /* fetch the result */
            result[2] = ADCDATA4;
            printf(" \n\r AN0=x%x AN3=x%x AN4=x%x",result[0],result[1],result[2] );
            /*
            * Process results here
            *
            * Note: Loop time determines the sampling time since all inputs are Class 1.
            * If the loop time is small and the next trigger happens before the completion
            * of set sample time, the conversion will happen only after the sample time
            * has elapsed.
            *
            */
         }
	}
}
/*********************************/
void initU1ART(void)
{
    // UART init
    // Pins initialization. !!!!! have to be adapted to hardware 
    TRISCbits.TRISC6 = 1;       //!  C6 digital input
    U1RXRbits.U1RXR = 5;        //!  SET RX to RC6 
    RPC7Rbits.RPC7R = 1;        //!  SET RC7 to TX    
    // disable UART1 and autobaud, TX and RX enabled only,8N1,idle=HIGH
    U1MODE = 0x0000;         
    U1STAbits.URXEN = 1;        //! Enable RX 
    U1STAbits.UTXEN = 1;        //! Enable TX
    U1BRG = (_PBCLK/(16*_UARTspeed)) - 1;
    //U1BRG = 32;               //! Baud Speed => 115200
    // Interrupt         
    IPC9bits.U1RXIP = 3;        //! set IPL 3
    IPC9bits.U1RXIS = 2;        //! sub-priority 2
    U1STAbits.URXISEL = 0;      //! when receive one character
    //! For future applications 
    IPC10bits.U1TXIP = 3;       //! set IPL 3
    IPC10bits.U1TXIS = 2;       //! sub-priority 2
    U1STAbits.UTXISEL = 2;      //! where transmit is empty     
    IFS1bits.U1TXIF = 0;        //!< Clear the Transmit Interrupt Flag
    IEC1bits.U1TXIE = 0;        //!< Disable Transmit Interrupts
    IFS1bits.U1RXIF = 0;        //!< Clear the Recieve Interrupt Flag
    IEC1bits.U1RXIE = 0;        //!< Disable Recieve Interrupt
    
    U1MODEbits.ON = 1;          //!< U1ART ON
}
void initADC(void)
{
        //! all digital
        ANSELA = 0; ANSELB = 0; ANSELC = 0; ANSELD = 0; ANSELE = 0; ANSELF = 0;
        ANSELG = 0; ANSELF = 0; 
        //! No pull-up resistor => necessairy to define ditital Output 
        CNPUA = 0; CNPUB= 0; CNPUC= 0; CNPUD= 0; CNPUE= 0; CNPUF= 0; CNPUG= 0; 
        CNPUF= 0;
        //! No pull-down resistor => necessairy to define ditital Output
        CNPDA = 0; CNPDB= 0; CNPDC= 0; CNPDD= 0; CNPDE= 0; CNPDF= 0; 
        CNPDG= 0; CNPDF= 0;
        //! No Change Notification (interruption generated by I/O )
        CNCONA = 0;  CNCONB = 0; CNCONC = 0; CNCOND = 0; CNCONE = 0; CNCONF = 0;
        CNCONG = 0;
        /* Configure ADCCON1 */
        ADCCON1 = 0; // No ADCCON1 features are enabled including: Stop-in-Idle, turbo,
                    // CVD mode, Fractional mode and scan trigger source.
        /* Configure ADCCON2 */
        ADCCON2 = 0; // Since, we are using only the Class 1 inputs, no setting is
                    // required for ADCDIV
        /* Initialize warm up time register */
        ADCANCON = 0; ADCANCONbits.WKUPCLKCNT = 5; // Wakeup exponent = 32 * TADx
        TRISAbits.TRISA0 = 1; ANSELAbits.ANSA0 = 1; CNPUAbits.CNPUA0=0;  CNPDAbits.CNPDA0=0;        //! AN0pic
        TRISAbits.TRISA1 = 1; ANSELAbits.ANSA1 = 1; CNPUAbits.CNPUA1=0;  CNPDAbits.CNPDA1=0;       //! AN1pic
        TRISBbits.TRISB0 = 1; ANSELBbits.ANSB0 = 1; CNPUBbits.CNPUB0=0;  CNPDBbits.CNPDB0=0;       //! AN2pic
        TRISBbits.TRISB1 = 1; ANSELBbits.ANSB1 = 1; CNPUBbits.CNPUB1=0;  CNPDBbits.CNPDB1=0;      //! AN3pic
        TRISBbits.TRISB2 = 1; ANSELBbits.ANSB2 = 1; CNPUBbits.CNPUB2=0;  CNPDBbits.CNPDB2=0;      //! AN4pic
        TRISBbits.TRISB3 = 1; ANSELBbits.ANSB3 = 1; CNPUBbits.CNPUB3=0;  CNPDBbits.CNPDB3=0;      //! AN5pic
        TRISCbits.TRISC0 = 1; ANSELCbits.ANSC0 = 1; CNPUCbits.CNPUC0=0;  CNPDCbits.CNPDC0=0;      //! AN6pic
        TRISCbits.TRISC1 = 1; ANSELCbits.ANSC1 = 1; CNPUCbits.CNPUC1=0;  CNPDCbits.CNPDC1=0;     //! AN7pic
        TRISCbits.TRISC2 = 1; ANSELCbits.ANSC2 = 1; CNPUCbits.CNPUC2=0;  CNPDCbits.CNPDC2=0;      //! AN8pic
        TRISAbits.TRISA11 = 1; ANSELAbits.ANSA11 = 1;CNPUAbits.CNPUA11=0;  CNPDAbits.CNPDA11=0;     //! AN9pic 
        
        //! CloseADC10();	
        ADCCON1bits.ON = 0;    //!CloseADC10();	
        //#define PARAM1  ADC_FORMAT_INTG | ADC_CLK_AUTO | ADC_AUTO_SAMPLING_ON
        ADCCON1bits.FRACT =0; ADCCON1bits.SELRES =3; //!12bits => ADC_FORMAT_INTG
        /* Set up the trigger sources */
        ADCTRGSNSbits.LVL0 = 0; // Edge trigger
        ADCTRGSNSbits.LVL3 = 0; // Edge trigger
        ADCTRGSNSbits.LVL4 = 0; // Edge trigger
        ADCTRG1bits.TRGSRC0 = 1; // Set AN0 to trigger from software.
        ADCTRG1bits.TRGSRC3 = 1; // Set AN3 to trigger from software.
        ADCTRG2bits.TRGSRC4 = 1; // Set AN4 to trigger from software. 
 
        
        
        
        
        
        /* Turn the ADC on */
        ADCCON1bits.ON = 1;
        /* Wait for voltage reference to be stable */
        while(!ADCCON2bits.BGVRRDY); // Wait until the reference voltage is ready
        while(ADCCON2bits.REFFLT); // Wait if there is a fault with the reference voltage
        /* Enable clock to analog circuit */
        ADCANCONbits.ANEN0 = 1; // Enable the clock to analog bias
        ADCANCONbits.ANEN3 = 1; // Enable the clock to analog bias
        ADCANCONbits.ANEN4 = 1; // Enable the clock to analog bias
        /* Wait for ADC to be ready */
        while(!ADCANCONbits.WKRDY0); // Wait until ADC0 is ready
        while(!ADCANCONbits.WKRDY3); // Wait until ADC1 is ready
        while(!ADCANCONbits.WKRDY4); // Wait until ADC2 is ready
        /* Enable the ADC module */
        ADCCON3bits.DIGEN0 = 1; // Enable ADC0
        ADCCON3bits.DIGEN3 = 1; // Enable ADC3
        ADCCON3bits.DIGEN4 = 1; // Enable ADC4
}
/*********************************/

 