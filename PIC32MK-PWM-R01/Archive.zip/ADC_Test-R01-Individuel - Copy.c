//!----------------------------------------------------------------------------
//! electronics-lis
//! CH-2000 Neuchatel
//! info@electronics-lis.com
//! https://electronics-lis.com
//! L. Lisowski 20 January 2018
//!----------------------------------------------------------------------------
//!----------------------------------------------------------------------------
// PIC32MK ADC tests
//!----------------------------------------------------------------------------
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <C:\Program Files (x86)\Microchip\xc32\v1.44\pic32mx\include\proc\p32mk1024mcf064.h>
#include <xc.h>            
#include <sys/attribs.h> 
//!----------------------------------------------------------------------------
//!----------------------------------------------------------------------------
//! This part need to be adapted for your application. 
#pragma config PWMLOCK = OFF, FUSBIDIO2 = OFF, FVBUSIO2 = OFF, PGL1WAY = OFF    
#pragma config PMDL1WAY = OFF, IOL1WAY = OFF, FUSBIDIO1 = OFF, FVBUSIO1 = OFF                    
// DEVCFG2
#pragma config FPLLIDIV = DIV_1, FPLLRNG = RANGE_5_10_MHZ, FPLLICLK = PLL_POSC         
#pragma config FPLLMULT = MUL_48, FPLLODIV = DIV_4, VBATBOREN = ON, DSBOREN = ON      
#pragma config DSWDTPS = DSPS32, DSWDTOSC = LPRC, DSWDTEN = OFF, FDSEN = OFF          
#pragma config BORSEL = HIGH, UPLLEN = OFF               
// DEVCFG1
#pragma config FNOSC = SPLL, DMTINTV = WIN_127_128, FSOSCEN = OFF, IESO = ON
#pragma config POSCMOD = HS, OSCIOFNC = ON, FCKSM = CSECME, WDTPS = PS1048576   
#pragma config WDTSPGM =STOP,WINDIS = NORMAL, FWDTEN = OFF, FWDTWINSZ = WINSZ_25
#pragma config DMTCNT = DMT31, FDMTEN = ON
// DEVCFG0
#pragma config DEBUG = OFF, JTAGEN = OFF, ICESEL = ICS_PGx1, TRCEN = ON
#pragma config BOOTISA = MIPS32,FSLEEP = OFF, DBGPER = PG_ALL, SMCLR = MCLR_NORM     
#pragma config SOSCGAIN = GAIN_2X, SOSCBOOST = ON, POSCGAIN = GAIN_LEVEL_3
#pragma config POSCBOOST = ON, EJTAGBEN = NORMAL 
// DEVCP
#pragma config CP = OFF                 // Code Protect (Protection Disabled)
//! That are my Configuration Bits version, you need adapt them for your application 
//!----------------------------------------------------------------------------
//!----------------------------------------------------------------------------
#define _SYSCLK 120000000L
#define _PBCLK (_SYSCLK/2)
#define _UARTspeed   115200
/*********************************/
//! Type declarations
/*********************************/
typedef signed char  int8;
typedef unsigned char uint8;
typedef short int16;
typedef unsigned short uint16;
typedef long int32;
typedef unsigned long uint32;
/************************************//**
** Macro Definitions
****************************************/
//! Don't forget !!! the result are uint32_l !!!!!!!!
#define TSTBIT(D,i) (uint32_l)D & ((uint32_l)i)
#define SETBIT(D,i) (D |= i)
#define CLRBIT(D,i) (D &= (~i))
#define ONmask      15
#define DIGEN0mask  16
/*********************************/
//! Local Variables
/*********************************/
char i, k;
int32 result[6];
/*********************************/
//! Function prototype
/*********************************/
void initU1ART(void);
void initANALOG(void);
void initADC(void);
/*********************************/
//! main 
void main()
{ 
  
    __builtin_enable_interrupts();  // global interrupt enable
    __XC_UART = 1;                  // printf on the U1ART    
    INTCONbits.MVEC = 1; // Set the interrupt controller for multi-vector mode  
    PMCONbits.ON = 0;               //! no PMP
    
    // Function initialization
    PMD5bits.U1MD = 0; //! Enable clock
    initU1ART();
    printf ("\n\r This is my first ADC test \n\r"); 
    initANALOG();       //! Analog part initialization
    initADC();          //! ADC initialization
    //! PBCLK2 clock initialization
    PB2DIVbits.ON = 1;              //! PBCLK2 clock  => ON
    PB5DIVbits.ON = 1; PB5DIVbits.PBDIV=1;//! PBCLK5 clock  => ON DIV = 2
    PB4DIVbits.ON = 1; PB4DIVbits.PBDIV=1;//! PBCLK5 clock  => ON DIV = 2
    PB3DIVbits.ON = 1; PB3DIVbits.PBDIV=1;//! PBCLK5 clock  => ON DIV = 2
    while (1) // U1ART test
	{
        while( !U1STAbits.URXDA);   //! wait until data available in RX buffer
        i = U1RXREG;                //1 Hit any key
        while( U1STAbits.UTXBF);    //! wait while TX buffer full
        U1TXREG = i;                //! Echo
        while( !U1STAbits.TRMT);    //! wait for last transmission to finish
        if (i == 'c')
        {
              /* Trigger a conversion */
            DAC2CONbits.DACDAT = 500;
            ADCCON3bits.GSWTRG = 1;
            /* Wait the conversions to complete */
            while (ADCDSTAT1bits.ARDY0 == 0);
            result[0] = ADCDATA0; 
            while (ADCDSTAT1bits.ARDY1 == 0);
            result[1] = ADCDATA1; 
            while (ADCDSTAT1bits.ARDY2 == 0);
            result[2] = ADCDATA2; 
            while (ADCDSTAT1bits.ARDY3 == 0);
            result[3] = ADCDATA3;
            while (ADCDSTAT1bits.ARDY4 == 0);
            result[4] = ADCDATA4;
            while (ADCDSTAT1bits.ARDY5 == 0);
            result[5] = ADCDATA5;
            
            printf("\n\r \tAD0=%lu \tAD1=%lu \tAD2=%lu \tAD3=%lu \tAD4=%lu \tAD5=%lu ",
                    result[0],result[1], result[2],result[3],result[4],result[5] );
            i= 's';
            /* Wait the conversions to complete */
            /*while (ADCFLTR1bits.AFRDY == 0);
            printf(" AD0=%d Cfg0=x%x", ADCFLTR1bits.FLTRDATA, ADCSYSCFG0bits.AN0 ) ;
            while (ADCFLTR3bits.AFRDY == 0);
            printf(" AD3=%d Cfg3=x%x", ADCFLTR3bits.FLTRDATA, ADCSYSCFG0bits.AN3 ) ;
            while (ADCFLTR4bits.AFRDY == 0);
            printf(" AD4=%d Cfg4=x%x    ",ADCFLTR4bits.FLTRDATA, ADCSYSCFG0bits.AN4 ) ;*/
        }
	}
}
/*********************************/
void initU1ART(void)
{
    // UART init
    // Pins initialization. !!!!! have to be adapted to hardware 
    TRISCbits.TRISC6 = 1;       //!  C6 digital input
    U1RXRbits.U1RXR = 5;        //!  SET RX to RC6 
    RPC7Rbits.RPC7R = 1;        //!  SET RC7 to TX    
    // disable UART1 and autobaud, TX and RX enabled only,8N1,idle=HIGH
    U1MODE = 0x0000;         
    U1STAbits.URXEN = 1;        //! Enable RX 
    U1STAbits.UTXEN = 1;        //! Enable TX
    U1BRG = (_PBCLK/(16*_UARTspeed)) - 1;
    //U1BRG = 32;               //! Baud Speed => 115200
    // Interrupt         
    IPC9bits.U1RXIP = 3;        //! set IPL 3
    IPC9bits.U1RXIS = 2;        //! sub-priority 2
    U1STAbits.URXISEL = 0;      //! when receive one character
    //! For future applications 
    IPC10bits.U1TXIP = 3;       //! set IPL 3
    IPC10bits.U1TXIS = 2;       //! sub-priority 2
    U1STAbits.UTXISEL = 2;      //! where transmit is empty     
    IFS1bits.U1TXIF = 0;        //!< Clear the Transmit Interrupt Flag
    IEC1bits.U1TXIE = 0;        //!< Disable Transmit Interrupts
    IFS1bits.U1RXIF = 0;        //!< Clear the Recieve Interrupt Flag
    IEC1bits.U1RXIE = 0;        //!< Disable Recieve Interrupt
    
    U1MODEbits.ON = 1;          //!< U1ART ON
}
void initANALOG(void)
{
    //! all digital
    ANSELA = 0; ANSELB = 0; ANSELC = 0; ANSELD = 0; ANSELE = 0; ANSELF = 0;
    ANSELG = 0; ANSELF = 0; 
    //! No pull-up resistor => necessairy to define ditital Output 
    CNPUA = 0; CNPUB= 0; CNPUC= 0; CNPUD= 0; CNPUE= 0; CNPUF= 0; CNPUG= 0; 
    CNPUF= 0;
    //! No pull-down resistor => necessairy to define ditital Output
    CNPDA = 0; CNPDB= 0; CNPDC= 0; CNPDD= 0; CNPDE= 0; CNPDF= 0; 
    CNPDG= 0; CNPDF= 0;
    //! two pull-down resistors 
    //CNPDBbits.CNPDB1 = 1; CNPDBbits.CNPDB2 = 1;
    //! No Change Notification (interruption generated by I/O )
    CNCONA = 0;  CNCONB = 0; CNCONC = 0; CNCOND = 0; CNCONE = 0; CNCONF = 0;
    CNCONG = 0;
    //! Disable and enable peripheral modules
    PMD2 = 1; //! Ampli op and comparator without clock
    
    /* Initialize pins as analog inputs */     
    TRISAbits.TRISA0 = 1; ANSELAbits.ANSA0 = 1;         //! AN0pic
    TRISAbits.TRISA1 = 1; ANSELAbits.ANSA1 = 1;       //! AN1pic
    TRISBbits.TRISB0 = 1; ANSELBbits.ANSB0 = 1;        //! AN2pic
    TRISBbits.TRISB1 = 1; ANSELBbits.ANSB1 = 1;       //! AN3pic
    TRISBbits.TRISB2 = 1; ANSELBbits.ANSB2 = 1;       //! AN4pic
    TRISBbits.TRISB3 = 1; ANSELBbits.ANSB3 = 1;       //! AN5pic 
    TRISCbits.TRISC10 = 0; ANSELCbits.ANSC10 = 1;       //! DAC2
    return;
}
void initADC(void)
{       
        uint8 k; 
        //PMD1bits.ADCMD = 0;         //! Enable clock
        //PMD1bits.DAC2MD = 0;        //! Enable clock
        //! Disable all analog inputs
        for (k=0; k<=7; k++) CLRBIT(ADCANCON,k); 
        //ADCANCONbits.ANEN7=ADCANCONbits.ANEN0=ADCANCONbits.ANEN1=0;
        //ADCANCONbits.ANEN2=ADCANCONbits.ANEN3=ADCANCONbits.ANEN4=ADCANCONbits.ANEN5=0;
        //! Configuration Register 
        ADC0CFG = DEVADC0; ADC1CFG = DEVADC1; ADC2CFG = DEVADC2; ADC3CFG = DEVADC3;
        ADC4CFG = DEVADC4; ADC5CFG = DEVADC5; //ADC6CFG = DEVADC6; 
        ADC7CFG = DEVADC7; 
        
        /* Turn the ADC off and reset all*/
        //ADCCON1bits.ON = 0;
        ADCCON1 = 0;
        /* Configure ADCCON1 */
        ADCCON1 = 0; // No ADCCON1 features are enabled including: Stop-in-Idle, turbo,
                    // CVD mode, Fractional mode and scan trigger source.
        /* Configure ADCCON2 */
        ADCCON2 = 0; // Since, we are using only the Class 1 inputs, no setting is
                    // required for ADCDIV
                 
        //ADCCON2bits.ADCDIV = 1; //! ADC7 clock divider ADCCON2bits.ADCDIV = 1;
        //ADCCON2bits.SAMC = 5;   //! Sample Time for the Shared ADC (ADC7) bits     
        /* Digital Disable Bit*/
        for (k=0; k<=7; k++) CLRBIT(ADCCON3,k+DIGEN0mask);
        ADCCON3bits.DIGEN0 = 0; ADCCON3bits.DIGEN1 = 0; ADCCON3bits.DIGEN2 = 0;
        ADCCON3bits.DIGEN3 = 0; ADCCON3bits.DIGEN4 = 0; ADCCON3bits.DIGEN5 = 0;
        ADCCON3bits.DIGEN7 = 0;
        /* Clock setting */
        ADCCON3 = 0;
        ADCCON3bits.ADCSEL = 0; // Select input clock source = PBCLK5
        ADCCON3bits.CONCLKDIV = 2; // Control clock frequency is half of input clock
        ADCCON3bits.VREFSEL = 0; // Select AVDD and AVSS as reference source
        
        ADCCON1bits.FRACT = 0; //! Fractional Output format
    
        /* Select ADC sample time and conversion clock */
        ADC0TIMEbits.ADCDIV = 2; // ADC0 clock frequency is half of control clock = TAD0
        ADC0TIMEbits.SAMC = 5; // ADC0 sampling time = 5 * TAD0
        ADC0TIMEbits.SELRES = 3; // ADC0 resolution is 12 bits
        ADC1TIMEbits.ADCDIV = 2; // ADC1 clock frequency is half of control clock = TAD1
        ADC1TIMEbits.SAMC = 5; // ADC1 sampling time = 5 * TAD1
        ADC1TIMEbits.SELRES = 3; // ADC1 resolution is 12 bits
        ADC2TIMEbits.ADCDIV = 2; // ADC2 clock frequency is half of control clock = TAD2
        ADC2TIMEbits.SAMC = 5; // ADC2 sampling time = 5 * TAD2
        ADC2TIMEbits.SELRES = 3; // ADC2 resolution is 12 bits
        ADC3TIMEbits.ADCDIV = 2; // ADC3 clock frequency is half of control clock = TAD2
        ADC3TIMEbits.SAMC = 5; // ADC3 sampling time = 5 * TAD2
        ADC3TIMEbits.SELRES = 3; // ADC3 resolution is 12 bits
        ADC4TIMEbits.ADCDIV = 2; // ADC4 clock frequency is half of control clock = TAD2
        ADC4TIMEbits.SAMC = 5; // ADC4 sampling time = 5 * TAD2
        ADC4TIMEbits.SELRES = 3; // ADC4 resolution is 12 bits
        ADC5TIMEbits.ADCDIV = 2; // ADC5 clock frequency is half of control clock = TAD2
        ADC5TIMEbits.SAMC = 5; // ADC5 sampling time = 5 * TAD2
        ADC5TIMEbits.SELRES = 3; // ADC5 resolution is 12 bits
        ADCCON2bits.SAMC = 5; ADCCON1bits.SELRES = 3;  ADCCON2bits.ADCDIV = 2; //! ADC7
        
        /* Select analog input for ADC modules, no presync trigger, not sync sampling */         
        ADCTRGMODEbits.SH5ALT = 0; 
        ADCTRGMODEbits.SH4ALT = 0; // ADC4 = AN4pic = CurD
        ADCTRGMODEbits.SH3ALT = 0; // ADC3 = AN3pic = CurB
        ADCTRGMODEbits.SH2ALT = 0; 
        ADCTRGMODEbits.SH1ALT = 0; // ADC0 = AN0pic = CurSup
        ADCTRGMODEbits.SH0ALT = 0; // ADC0 = AN0pic = CurSup 
        ADCTRGMODEbits.STRGEN0 = 1; ADCTRGMODEbits.STRGEN1 = 1; ADCTRGMODEbits.STRGEN2 = 1;
        ADCTRGMODEbits.STRGEN3 = 1; ADCTRGMODEbits.STRGEN4 = 1; ADCTRGMODEbits.STRGEN5 = 1;
        ADCIMCON1bits.SIGN0 = 0; // unsigned data format
        ADCIMCON1bits.DIFF0 = 0; // Single ended mode
        ADCIMCON1bits.SIGN1 = 0; // unsigned data format
        ADCIMCON1bits.DIFF1 = 0; // Single ended mode
        ADCIMCON1bits.SIGN2 = 0; // unsigned data format
        ADCIMCON1bits.DIFF2 = 0; // Single ended mode
        ADCIMCON1bits.SIGN3 = 0; // unsigned data format
        ADCIMCON1bits.DIFF3 = 0; // Single ended mode
        ADCIMCON1bits.SIGN4 = 0; // unsigned data format
        ADCIMCON1bits.DIFF4 = 0; // Single ended mode
        ADCIMCON1bits.SIGN5 = 0; // unsigned data format
        ADCIMCON1bits.DIFF5 = 0; // Single ended mode
        /* Set up the trigger sources */
        //ADCCON1bits.STRGSRC = 1; //! Scan Software edge trigger 
        //ADCCON1bits.STRGLVL = 0; //! Scan 
        
        ADCTRGSNSbits.LVL0 = 0; // Positive Edge trigger
        ADCTRGSNSbits.LVL1 = 0; // Positive Edge trigger
        ADCTRGSNSbits.LVL2 = 0; // Positive Edge trigger
        ADCTRGSNSbits.LVL3 = 0; // Positive Edge trigger
        ADCTRGSNSbits.LVL4 = 0; // Positive Edge trigger
        ADCTRGSNSbits.LVL5 = 0; // Positive Edge trigger
        ADCTRG1bits.TRGSRC0 = 1; // Set AN0 to trigger edge from software
        ADCTRG1bits.TRGSRC1 = 1; // Set AN1 to trigger edge from software
        ADCTRG1bits.TRGSRC2 = 1; // Set AN2 to trigger edge from software
        ADCTRG1bits.TRGSRC3 = 1; // Set AN3 to trigger edge from software
        ADCTRG2bits.TRGSRC4 = 1; // Set AN4 to trigger edge from software
        ADCTRG2bits.TRGSRC5 = 1; // Set AN5 to trigger edge from software
        
         /* Configure ADCGIRQENx = No interrupts are used */
        ADCGIRQEN1 = 0; ADCGIRQEN2 = 0;  
        /* Configure ADCCSSx No scanning is used */
        ADCCSS1 = 0; ADCCSS2 = 0; 
        /* DAC disabled*/
        DAC1CON = DAC2CON = DAC3CON = 0;
        DAC2CONbits.ON = 1;         //! DAC2 ON 
        DAC2CONbits.DACOE = 1;      //! pin ON
        DAC2CONbits.REFSEL = 3;     //! AVdd
        
        /* Configure ADCCMPCONx No analog comparators are used.*/
        CM1CON = CM2CON = CM3CON = CM4CON = CM5CON = 0;
        /* Configure ADCCMPCONx No digital comparators are used.*/
        ADCCMPCON1 = 0; 
        ADCCMPCON2 = 0; // register to '0' ensures that the comparator is disabled.
        ADCCMPCON3 = 0; // Other registers are ?don't care?.
        ADCCMPCON4 = 0; 
        /* Configure ADCFLTRx = No oversampling filters are used.*/
        ADCFLTR1 = 0; ADCFLTR2 = 0; 
        ADCFLTR3 = 0; ADCFLTR4 = 0; //ADCFLTR5 = 0; ADCFLTR6 = 0;        
        
        /* Early interrupt = No early interrupt */
        ADCEIEN1 = 0; ADCEIEN2 = 0;
        ADCANCON = 0; ADCANCONbits.WKUPCLKCNT = 5; // Wakeup exponent = 32 * TADx
        /* Filtring */
        /*ADCFLTR3 = ADCFLTR4 = 0;
        ADCFLTR1 = 0;
        ADCFLTR1bits.AFEN =1;  ADCFLTR1bits.OVRSAM = 1; ADCFLTR1bits.DFMODE=1; ADCFLTR1bits.CHNLID =0; 
        ADCFLTR3bits.AFEN =1;  ADCFLTR3bits.OVRSAM = 1; ADCFLTR3bits.DFMODE=1; ADCFLTR3bits.CHNLID =3;  
        ADCFLTR4bits.AFEN =1;  ADCFLTR4bits.OVRSAM = 1; ADCFLTR4bits.DFMODE=1; ADCFLTR4bits.CHNLID =4;*/
        /* Individual conversion*/
        //ADCCON3bits.RQCNVRT = 1;
        //ADCCON3bits.ADINSEL = 4; //! AN0
           
        /* Turn the ADC on */
        ADCCON1bits.ON = 1;
        /* Wait for voltage reference to be stable */
        while(!ADCCON2bits.BGVRRDY); // Wait until the reference voltage is ready
        while(ADCCON2bits.REFFLT); // Wait if there is a fault with the reference voltage
        /* Enable clock to analog circuit */
        ADCANCONbits.ANEN0 = 1; // Enable the clock to analog bias
        ADCANCONbits.ANEN1 = 1; // Enable the clock to analog bias
        ADCANCONbits.ANEN2 = 1; // Enable the clock to analog bias
        ADCANCONbits.ANEN3 = 1; // Enable the clock to analog bias
        ADCANCONbits.ANEN4 = 1; // Enable the clock to analog bias
        ADCANCONbits.ANEN5 = 1; // Enable the clock to analog bias
        /* Wait for ADC to be ready */
        while(!ADCANCONbits.WKRDY0); // Wait until ADC0 is ready
        while(!ADCANCONbits.WKRDY1); // Wait until ADC0 is ready
        while(!ADCANCONbits.WKRDY2); // Wait until ADC0 is ready
        while(!ADCANCONbits.WKRDY3); // Wait until ADC3 is ready
        while(!ADCANCONbits.WKRDY4); // Wait until ADC4 is ready
        while(!ADCANCONbits.WKRDY5); // Wait until ADC0 is ready
        /* Enable the ADC module */
        ADCCON3bits.DIGEN0 = 1; // Enable ADC0
        ADCCON3bits.DIGEN1 = 1; // Enable ADC0
        ADCCON3bits.DIGEN2 = 1; // Enable ADC0
        ADCCON3bits.DIGEN3 = 1; // Enable ADC3
        ADCCON3bits.DIGEN4 = 1; // Enable ADC4
        ADCCON3bits.DIGEN5 = 1; // Enable ADC0
}
/*********************************/

 