//!----------------------------------------------------------------------------
//! electronics-lis
//! CH-2000 Neuchatel
//! info@electronics-lis.com
//! https://electronics-lis.com
//! L. Lisowski 20 January 2018
//!----------------------------------------------------------------------------
//!----------------------------------------------------------------------------
// PIC32MK ADC tests
//!----------------------------------------------------------------------------
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <C:\Program Files (x86)\Microchip\xc32\v1.44\pic32mx\include\proc\p32mk1024mcf064.h>
#include <xc.h>            
#include <sys/attribs.h> 
//!----------------------------------------------------------------------------
//!----------------------------------------------------------------------------
//! This part need to be adapted for your application. 
#pragma config PWMLOCK = OFF, FUSBIDIO2 = OFF, FVBUSIO2 = OFF, PGL1WAY = OFF    
#pragma config PMDL1WAY = OFF, IOL1WAY = OFF, FUSBIDIO1 = OFF, FVBUSIO1 = OFF                    
// DEVCFG2
#pragma config FPLLIDIV = DIV_1, FPLLRNG = RANGE_5_10_MHZ, FPLLICLK = PLL_POSC         
#pragma config FPLLMULT = MUL_48, FPLLODIV = DIV_4, VBATBOREN = ON, DSBOREN = ON      
#pragma config DSWDTPS = DSPS32, DSWDTOSC = LPRC, DSWDTEN = OFF, FDSEN = OFF          
#pragma config BORSEL = HIGH, UPLLEN = OFF               
// DEVCFG1
#pragma config FNOSC = SPLL, DMTINTV = WIN_127_128, FSOSCEN = OFF, IESO = ON
#pragma config POSCMOD = HS, OSCIOFNC = ON, FCKSM = CSECME, WDTPS = PS1048576   
#pragma config WDTSPGM =STOP,WINDIS = NORMAL, FWDTEN = OFF, FWDTWINSZ = WINSZ_25
#pragma config DMTCNT = DMT31, FDMTEN = ON
// DEVCFG0
#pragma config DEBUG = OFF, JTAGEN = OFF, ICESEL = ICS_PGx1, TRCEN = ON
#pragma config BOOTISA = MIPS32,FSLEEP = OFF, DBGPER = PG_ALL, SMCLR = MCLR_NORM     
#pragma config SOSCGAIN = GAIN_2X, SOSCBOOST = ON, POSCGAIN = GAIN_LEVEL_3
#pragma config POSCBOOST = ON, EJTAGBEN = NORMAL 
// DEVCP
#pragma config CP = OFF                 // Code Protect (Protection Disabled)
//! That are my Configuration Bits version, you need adapt them for your application 
//!----------------------------------------------------------------------------
//!----------------------------------------------------------------------------
/*********************************/
//! Type declarations
/*********************************/
typedef signed char  int8;
typedef unsigned char uint8;
typedef short int16;
typedef unsigned short uint16;
typedef signed int int32;
typedef unsigned int uint32;
/************************************//**
** Macro Definitions
****************************************/
//! Don't forget !!! the result are uint32_l !!!!!!!!
#define TSTBIT(D,i) (D>>i & 1)
#define SETBIT(D,i) (D |= ((uint32)1<<i))
#define CLRBIT(D,i) (D &= (uint32)(~i))
//#define SETPARA(D,p,i) (D |= (p<<i))
#define DIGEN0mask              16
#define REG_SHIFT               4
#define ADC_MAX_LOOPS           100
#define SYSCLK                  120000000L
#define PBCLK                   (SYSCLK/2)
#define UARTspeed               115200
#define TRUE                    1
#define FALSE                   0
/*********************************/
//! Local Variables
/*********************************/
char i, k;
uint32  reg ,pos, New, *Val;
uint8   MaxLoops,NbrLoops;
uint8   StrNbrLoops[5];
static uint32  result[6];
/*********************************/
//! Function prototype
/*********************************/
void initU1ART(void);
void initANALOG(void);
void initADC(void);
uint8 VerifStatZERO(volatile uint32 * reg, uint32 BitPos);
uint8 VerifStatONE(volatile uint32 *reg, uint32 mask);
void SetPara(volatile uint32 * reg, uint32 para, uint32 ParaPos);
/*********************************/
//! main 
void main()
{  
    __builtin_enable_interrupts();  // global interrupt enable
    __XC_UART = 1;                  // printf on the U1ART    
    INTCONbits.MVEC = 1; // Set the interrupt controller for multi-vector mode  
    PMCONbits.ON = 0;               //! no PMP
    
    // Function initialization
    PMD5bits.U1MD = 0; //! Enable clock
    initU1ART();
    printf ("\n\r This is my first ADC test \n\r"); 
    initANALOG();       //! Analog part initialization
    initADC();          //! ADC initialization
    
    //! PBCLK2 clock initialization
    PB2DIVbits.ON = 1;              //! PBCLK2 clock  => ON
    PB5DIVbits.ON = 1; PB5DIVbits.PBDIV=1;//! PBCLK5 clock  => ON DIV = 2
    while (1) // U1ART test
	{
        while( !U1STAbits.URXDA);   //! wait until data available in RX buffer
        i = U1RXREG;                //1 Hit any key
        while( U1STAbits.UTXBF);    //! wait while TX buffer full
        U1TXREG = i;                //! Echo
        while( !U1STAbits.TRMT);    //! wait for last transmission to finish
        if (i == 'c')
        {
            /* Trigger a conversion */
            //DAC2CONbits.DACDAT = 500; //! 
            SetPara(&DAC2CON,1000,16);    //! DAC value to test one ADC
            SETBIT(ADCCON3,6);    //! GSWTRG =>Global Software Trigger bit
            for (k=0; k<=5; k++){
                VerifStatONE( &ADCDSTAT1, k);   //!ARDYx data is ready
                Val = &ADCDATA0 + k*4;
                result[k] = *Val;                 //! Read result 
                i= 's';
            }                                
           printf("\n\r \tAD0=%lu \tAD1=%lu \tAD2=%lu \tAD3=%lu \tAD4=%lu \tAD5=%lu ",
                    result[0],result[1], result[2],result[3],result[4],result[5] );          
            /* Wait the conversions to complete */
            /*while (ADCFLTR1bits.AFRDY == 0);
            printf(" AD0=%d Cfg0=x%x", ADCFLTR1bits.FLTRDATA, ADCSYSCFG0bits.AN0 ) ;
            while (ADCFLTR3bits.AFRDY == 0);
            printf(" AD3=%d Cfg3=x%x", ADCFLTR3bits.FLTRDATA, ADCSYSCFG0bits.AN3 ) ;
            while (ADCFLTR4bits.AFRDY == 0);
            printf(" AD4=%d Cfg4=x%x    ",ADCFLTR4bits.FLTRDATA, ADCSYSCFG0bits.AN4 ) ;*/
        }
	}
}
/*********************************/
void initU1ART(void)
{
    // UART init
    // Pins initialization. !!!!! have to be adapted to hardware 
    TRISCbits.TRISC6 = 1;       //!  C6 digital input
    U1RXRbits.U1RXR = 5;        //!  SET RX to RC6 
    RPC7Rbits.RPC7R = 1;        //!  SET RC7 to TX    
    // disable UART1 and autobaud, TX and RX enabled only,8N1,idle=HIGH
    U1MODE = 0x0000;         
    U1STAbits.URXEN = 1;        //! Enable RX 
    U1STAbits.UTXEN = 1;        //! Enable TX
    U1BRG = (PBCLK/(16*UARTspeed)) - 1;
    //U1BRG = 32;               //! Baud Speed => 115200
    // Interrupt         
    IPC9bits.U1RXIP = 3;        //! set IPL 3
    IPC9bits.U1RXIS = 2;        //! sub-priority 2
    U1STAbits.URXISEL = 0;      //! when receive one character
    //! For future applications 
    IPC10bits.U1TXIP = 3;       //! set IPL 3
    IPC10bits.U1TXIS = 2;       //! sub-priority 2
    U1STAbits.UTXISEL = 2;      //! where transmit is empty     
    IFS1bits.U1TXIF = 0;        //!< Clear the Transmit Interrupt Flag
    IEC1bits.U1TXIE = 0;        //!< Disable Transmit Interrupts
    IFS1bits.U1RXIF = 0;        //!< Clear the Recieve Interrupt Flag
    IEC1bits.U1RXIE = 0;        //!< Disable Recieve Interrupt
    
    U1MODEbits.ON = 1;          //!< U1ART ON
}
void initANALOG(void)
{
    //! all digital
    ANSELA = 0; ANSELB = 0; ANSELC = 0; ANSELD = 0; ANSELE = 0; ANSELF = 0;
    ANSELG = 0; ANSELF = 0; 
    //! No pull-up resistor => necessairy to define ditital Output 
    CNPUA = 0; CNPUB= 0; CNPUC= 0; CNPUD= 0; CNPUE= 0; CNPUF= 0; CNPUG= 0; 
    CNPUF= 0;
    //! No pull-down resistor => necessairy to define ditital Output
    CNPDA = 0; CNPDB= 0; CNPDC= 0; CNPDD= 0; CNPDE= 0; CNPDF= 0; 
    CNPDG= 0; CNPDF= 0;
    //! two pull-down resistors 
    //CNPDBbits.CNPDB1 = 1; CNPDBbits.CNPDB2 = 1;
    //! No Change Notification (interruption generated by I/O )
    CNCONA = 0;  CNCONB = 0; CNCONC = 0; CNCOND = 0; CNCONE = 0; CNCONF = 0;
    CNCONG = 0;
    //! Disable and enable peripheral modules
    PMD2 = 1; //! Ampli op and comparator without clock
    
    /* Initialize pins as analog inputs */ 
    SETBIT(TRISA,0);  SETBIT(ANSELA,0);     //! AN0pic to pin A0
    SETBIT(TRISA,1);  SETBIT(ANSELA,1);     //! AN1pic to pin A1 
    SETBIT(TRISB,0);  SETBIT(ANSELA,0);     //! AN2pic to pin A2
    SETBIT(TRISB,1);  SETBIT(ANSELA,1);     //! AN3pic to pin A3
    SETBIT(TRISB,2);  SETBIT(ANSELA,2);     //! AN4pic to pin A4
    SETBIT(TRISB,3);  SETBIT(ANSELA,3);     //! AN5pic to pin A5
    CLRBIT(TRISC,0);  SETBIT(ANSELA,3);     //! DAC2 output
    
    /* Configure ADCCMPCONx No analog comparators are used.*/
        CM1CON = CM2CON = CM3CON = CM4CON = CM5CON = 0;
    /* DAC disabled*/
        DAC1CON = DAC2CON = DAC3CON = 0;
    return;
}
void initADC(void)
{       
        //! Disable all analog inputs
        for (k=0; k<=7; k++) CLRBIT(ADCANCON,k); 
        //! Configuration Register 
        ADC0CFG = DEVADC0; ADC1CFG = DEVADC1; ADC2CFG = DEVADC2; ADC3CFG = DEVADC3;
        ADC4CFG = DEVADC4; ADC5CFG = DEVADC5; //ADC6CFG = DEVADC6; 
        ADC7CFG = DEVADC7;        
        /* Turn the ADC off and reset all bits*/
        ADCCON1 = 0;
        /* Configure ADCCON1 */
        ADCCON1 = 0; // No ADCCON1 features are enabled including: Stop-in-Idle, turbo,
                    // CVD mode, Fractional mode and scan trigger source.
        /* Configure ADCCON2 */
        ADCCON2 = 0; // Since, we are using only the Class 1 inputs, no setting is
                    // required for ADCDIV    
        /* Digital Disable Bit*/
        for (k=0; k<=7; k++) CLRBIT(ADCCON3,k+DIGEN0mask);
         /* Global clock setting */
        ADCCON3 = 0;
        //SetPara(&ADCCON3,0,30); //! ADCSEL=0 => Select input clock source = PBCLK5
        //SetPara(&ADCCON3,2,24); //! CONCLKDIV=2 => Control clock frequency is half of input clock
        //SetPara(&ADCCON3,0,13); //! VREFSEL=0 => elect AVDD and AVSS as reference source
        //SetPara(&ADCCON1,0,23); //! FRACT=0 => Integer format output
        /* Select ADC0-5 sample time, conversion clock and resolution */ 
        for (k=0; k<=5; k++){
            Val = &ADC0TIME + k*REG_SHIFT;
            SetPara(Val,3,24);  //! SELRES=3 => resolution is 12 bits
            SetPara(Val,2,16);  //! ADCDIV=2 => ADC channel clock frequency
            SetPara(Val,5,0);   //! SAMC=5 => ADC0 sampling time = 5 * TAD0
            pos = 16 + k; 
            CLRBIT(ADCTRGMODE,pos); //! SHxALT => Select analog input for ADC modules
            pos = 0 + k; 
            SETBIT(ADCTRGMODE,pos); //! Presynchronized Triggers ???????
            CLRBIT(ADCTRGSNS,pos); //! LVLx => Positive Edge trigger
            pos = 0 + 2*k; 
            CLRBIT(ADCTRGMODE,pos); //! SIGNx => Unsigned data format
            pos = 1 + 2*k; //! DIFF0  to  DIFF5 bit position
            CLRBIT(ADCIMCON1,pos); //! DIFFx => Single ended mode            
        }
        /* Select ADC6 sample time, conversion clock and resolution */
        SetPara(&ADCCON2,2,16); SetPara(&ADCCON2,5,0); SetPara(&ADCCON2,3,24);
           
        for (k=0; k<=3; k++){       //! Trigger edge from software
            pos = 0 + 8*k; //! TRGSRC0  to  TRGSRC3 bit position => ADCTRG1
            SetPara(&ADCTRG1,1,pos); //! TRGSRCx => Positive Edge trigger
        }
        for (k=4; k<=5; k++){       //! Trigger edge from software
            pos = 0 + 8*k; //! TRGSRC4  to  TRGSRC5 bit position => ADCTRG1
            SetPara(&ADCTRG2,1,pos); //! Positive Edge trigger
        }
        /* Configure ADCGIRQENx = No interrupts are used */
        ADCGIRQEN1 = 0; ADCGIRQEN2 = 0;  
        /* Configure ADCCSSx No scanning is used */
        ADCCSS1 = 0; ADCCSS2 = 0; 
        //! DAC2 connected to one of ADC for test DAC and ADC
        SETBIT(DAC2CON,15);      //! ON=1 => CDAC Enable bit
        SETBIT(DAC2CON,8);       //! DACOE=1 => CDAC Output Buffer Enable bit        
        //SetPara(&DAC2CON,3,0);    //! REFSEL=3=> Reference Source Select = AVdd      
        /* Configure ADCCMPCONx No digital comparators are used.*/
        ADCCMPCON1 = 0; 
        ADCCMPCON2 = 0; // register to '0' ensures that the comparator is disabled.
        ADCCMPCON3 = 0; // Other registers are ?don't care?.
        ADCCMPCON4 = 0;         
        /* Early interrupt = No early interrupt */
        ADCEIEN1 = 0; ADCEIEN2 = 0;
        /* Initial reset*/
        ADCANCON = 0; 
        SetPara(&ADCANCON,5,24); //! WKUPCLKCNT=5 => Wakeup exponent = 32 * TADx 
        /* Filtering and oversampling comment or not requested part*/
        /* Configure ADCFLTRx = No oversampling filters are used.*/
        ADCFLTR1 = 0; ADCFLTR2 = 0; ADCFLTR3 = 0; ADCFLTR4 = 0; 
        //! Commented filtering sequence
        for(k=1; k<=4; k++ ){
            reg = (ADCFLTR1 + k*REG_SHIFT);
            SETBIT(reg,15);     //! AFEN=1 => Filter enable
            SETPARA(reg,1,26);  //! OVRSAM=1 =>  Oversampling Filter Ratio=16
            SETBIT(reg,1,29);   //! DFMODE=1 => Filter ?x? works in Averaging mode
            pos = k-1;
            SETPARA(reg,0,pos); //! Digital Filter Analog Input Selection
                                //! ADC0 to Filter 1, ADC1 to 2 etc.
        }
        /* Individual conversion example*/
        /*SETBIT(ADCCON3,8);      //! RQCNVRT=1 => Individual ADC Input Conversion
        SETPARA(ADCCON3,0,0);       //! ADINSEL=0 => ADC0 as input 
        //ADCCON3bits.ADINSEL = 4;  //! AN0*/
           
        /* Turn the ADC on */
        SETBIT(ADCCON1,15);     //! ADC module enabled
        /* Wait for voltage reference to be stable */
        if(VerifStatONE(&ADCCON2,31)){} else return;//! BGVRRDY=> Reference Voltage Status
        if(VerifStatZERO(&ADCCON2,30)){} else return;//! REFFLT=> Reference OK
        
        //while(!(TSTBIT(ADCCON2,30))); //! REFFLT=> VREF/AVDD BOR Fault Status
        /* Enable clock to analog circuit */
        for(k=0; k<=5; k++) {
            SETBIT(ADCANCON,k);     //!ANENx=1 =>  Enable the clock to analog bias          
            pos = k + 8; 
            if(VerifStatONE(&ADCANCON,pos)){} else return; //! WKRDYx => Wake-up Status
            //VerifStatONE( &ADCANCON, pos);      
            pos = k + 16;        
            SETBIT(ADCCON3,pos);            //! ADCx =>Digital Enable bit 
        }
        SETBIT(ADCANCON,7);     //! ANEN7=1 Shared ADC7 (ADC7) Analog Enable
        VerifStatONE( &ADCANCON, 15);      //! WKRDY7 => Wake-up Status
        SETBIT(ADCCON3,23);     //! ADC7=>Digital Enable bit
 }
/*********************************/
uint8 VerifStatZERO(volatile uint32 * reg, uint32 BitPos)
{     
    MaxLoops = ADC_MAX_LOOPS;
    NbrLoops = 0;               //! To test if loops is well implemented
    while (MaxLoops--){
        NbrLoops++;
        if(TSTBIT(*reg,BitPos) == 0){
            sprintf(StrNbrLoops,"\n\r ==Zero NbrLoops=%u \tRegAddr=x%x",NbrLoops,reg);
            puts(StrNbrLoops);
            return (TRUE);
        }
    }
    printf("\n\r Error==0 BitPos=x%x  RegAddr=x%x", BitPos,reg);
    return (FALSE);
}
uint8 VerifStatONE(volatile uint32 * reg, uint32 BitPos)
{     
    MaxLoops = ADC_MAX_LOOPS;
    NbrLoops = 0;               //! To test if loops is well implemented
    while (MaxLoops--){
        NbrLoops++;
        if(TSTBIT(*reg,BitPos) == 1){
            sprintf(StrNbrLoops,"\n\r ==ONE \tNbrLoops=%u RegAddr=x%x",NbrLoops,reg);
            puts(StrNbrLoops);
            return (TRUE);
        }
    }
    printf("\n\r Error==1 \tBitPos=%u  \tRegAddr=x%x", BitPos,reg);
    return (FALSE);
}
void SetPara(volatile uint32 * reg, uint32 para, uint32 ParaPos)
{     
    *reg |= (para<<ParaPos);
    return;
}  